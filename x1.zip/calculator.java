package com.dsp;
import java.io.IOException;
import java.io.PrintWriter;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

public class Calculator extends HttpServlet {
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
    ows ServletException, IOException {
    double num1 = Double.parseDouble(request.getParameter("num1"));
    double num2 = Double.parseDouble(request.getParameter("num2"));

    Server obj = new Server();
    PrintWriter out = response.getWriter();

    out.println("<html>");
    out.println("<body>");
    out.println("<h1>Result of Addition : "+obj.add(num1,num2));
    out.println("<h1>Result of Subtraction : "+obj.sub(num1,num2));
    out.println("<h1>Result of Multiplication : "+obj.mul(num1,num2));

    if(num2 != 0)
        out.println("<h1>Result of Division : "+obj.div(num1,num2));
    else
        out.println("<h1>Result of Division : "+ "NaN");
    out.println("</body>");
    out.println("</html>");
    }
}