package com.dsp;
import jakarta.jws.WebMethod;
import jakarta.jws.WebParam;
import jakarta.jws.WebService;
@WebService(serviceName = "Calculator")
public class Server {
    @WebMethod(operationName = "add")
    public double add(@WebParam(name = "num1") double num1, @WebParam(name = "num2") double num2) {
        double sum;
        sum = num1 + num2;
        return sum;
    }
    @WebMethod(operationName = "sub")
    public double sub(@WebParam(name = "num1") double num1, @WebParam(name = "num2") double num2) {
        double diff;
        diff = num1 - num2;
        return diff;
    }
    @WebMethod(operationName = "mul")
    public double mul(@WebParam(name = "num1") double num1, @WebParam(name = "num2") double num2) {
        double prod;
        prod = num1 * num2;
        return prod;
    }
    @WebMethod(operationName = "div")
    public double div(@WebParam(name = "num1") double num1, @WebParam(name = "num2") double num2) {
        double ans;
        ans = num1 / num2;
        return ans;
    }
}